package J06008;

public class MonHoc {
  private String maMH, tenMH;

  public MonHoc(String maMH, String tenMH) {
    this.maMH = maMH;
    this.tenMH = tenMH;
  }

  public String getMaMH() {
    return maMH;
  }

  public String getTenMH() {
    return tenMH;
  }

}
