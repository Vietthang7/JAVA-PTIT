package J07059;

import java.util.*;
import java.io.*;

public class Main {

    public static void main(String[] args) throws FileNotFoundException {
        Scanner sc = new Scanner(new File("CATHI.in"));
        ArrayList<caThi> arr = new ArrayList<>();
        int t = Integer.parseInt(sc.nextLine());
        for (int i = 1; i <= t; i++) {
            arr.add(new caThi("C" + String.format("%03d", i), sc.nextLine(), sc.nextLine(), sc.nextLine()));
        }
        Collections.sort(arr, new Comparator<caThi>() {
            public int compare(caThi t, caThi t1) {
                if (t.ngayThi().compareTo(t1.ngayThi()) != 0) {
                    return t.ngayThi().compareTo(t1.ngayThi());
                } else {
                    if (t.getGioThi().compareTo(t1.getGioThi()) != 0) {
                        return t.getGioThi().compareTo(t1.getGioThi());
                    } else {
                        return t.getMa().compareTo(t1.getMa());
                    }
                }
            }
        });
        for (caThi x : arr) {
            System.out.println(x);
        }

    }
}
